import { LightningElement, api, track } from 'lwc';
import { OmniscriptBaseMixin } from 'omnistudio/omniscriptBaseMixin';
import pubsub from 'omnistudio/pubsub';


export default class OmniData extends OmniscriptBaseMixin(LightningElement) {
    @api json;
    @api required;
    @track value;
    connectedCallback() {
        console.log(this.required,'validdddd', JSON.parse(JSON.stringify(this.omniJsonDataStr)));
    }


    
    renderedCallback(){
    pubsub.register('omniscript_action', {
    data: this.handleOmniAction.bind(this),
});
}

handleOmniAction(data){
   this.sum= data.Sum;
   this.value = data.Sum;
   if(this.required == "true" && !data.Sum ){
       this.validateAction();
   }
   console.log('this.sum',data.Sum, this.required);
}

nameHandler(event){

     this.myData = {
   "Ste" : {
      "value" : event.detail.value,
      "valid" : true
   },
   "Anotherprop" : {
      "prop1" : "anothervalue"
   }

}
  this.omniUpdateDataJson(this.myData);
  //const jsonData = JSON.parse(JSON.stringify(this.omniJsonData));
   console.log('validdddd',JSON.parse(JSON.stringify(this.omniJson)));
   console.log('jsonData',this.maxWords);
   //this.renderedCallbac();
//this.omniApplyCallResp(this.myData);
}


validateAction(){
let fieldErrorMsg="Please Enter the";
this.template.querySelectorAll("lightning-input").forEach(item => {
let fieldValue=item.value;
 this.value = item.value;
 console.log('item.value',item.value);
let fieldLabel=item.label;
if(!fieldValue){
item.setCustomValidity(fieldErrorMsg+' '+fieldLabel);
}

item.reportValidity();
});
}

// jsonData; 

//     renderedCallback(){

//         //register the pubsub event
//         pubsub.register('omniscript_step', {
//             data: this.handleOmniStepLoadData.bind(this),
//         });
//     }
    
//     handleOmniStepLoadData(data) {
//         // perform logic to handle the pubsub data from the Step

//         //console.log('pubsub data -- '+ JSON.stringify(data)  ); 
//         this.jsonData = data.CallerType ;         
//         console.log('jsonData -- '+ JSON.stringify(data.CallerType)  ); 
//         console.log('jsonData -- '+ JSON.stringify(data.CallerType)  ); 
//     }
}